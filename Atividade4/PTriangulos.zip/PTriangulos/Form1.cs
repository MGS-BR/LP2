﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{

    public partial class Form1 : Form
    {
        public double lado1, lado2, lado3, resultado;

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado3.Text, out lado3))
            {
                errorProvider3.SetError(txtLado3, "Valor Inválido");
                txtLado3.Focus();
            }
            else if (lado3 <= 0)
            {
                errorProvider3.SetError(txtLado3, "O Número deve maior que zero");
                txtLado3.Focus();
            }
            else
            {
                errorProvider3.SetError(txtLado3, "");
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (!(Math.Abs(lado2-lado3) < lado1 && lado1 < lado2 + lado3))
            {
                txtResultado.Text = "Valor de Lado 1 inválido";
            }
            else if(!(Math.Abs(lado1 - lado3) < lado2 && lado2 < lado1 + lado3))
            {
                txtResultado.Text = "Valor de Lado 2 inválido";
            }
            else if (!(Math.Abs(lado1 - lado2) < lado3 && lado3 < lado1 + lado2))
            {
                txtResultado.Text = "Valor de Lado 3 inválido";
            }
            else if (lado1 == lado2 && lado2 == lado3)
            {
                txtResultado.Text = "Triângulo Retângulo";
            }
            else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
            {
                txtResultado.Text = "Triângulo Isóceles";
            }
            else
            {
                txtResultado.Text = "Triângulo Escaleno";
            }
        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado2.Text, out lado2))
            {
                errorProvider2.SetError(txtLado2, "Valor Inválido");
                txtLado2.Focus();
            }
            else if (lado2 <= 0)
            {
                errorProvider2.SetError(txtLado2, "O Número deve maior que zero");
                txtLado2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtLado2, "");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtLado1.Text, out lado1))
            {
                errorProvider1.SetError(txtLado1, "Valor Inválido");
                txtLado1.Focus();
            }
            else if(lado1 <= 0)
            {
                errorProvider1.SetError(txtLado1, "O Número deve maior que zero");
                txtLado1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtLado1, "");
            }
        }
    }
}
