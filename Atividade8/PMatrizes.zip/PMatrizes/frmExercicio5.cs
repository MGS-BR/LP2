﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string compara;
            char[,] respostas = new char[3,10];
            char[] gabarito = new char[] {'A', 'B', 'C', 'D','E','A','B','C','D','E'};
            char[] opcoes = new char[5] { 'A', 'B', 'C', 'D', 'E' };

            for (int alunos = 0; alunos < 3; alunos++)
            {
                for (int questoes = 0; questoes < 10; questoes++)
                {
                    compara = Interaction.InputBox("Gabarito", "Digite suas respostas: ");

                    if (!char.TryParse(compara, out respostas[alunos, questoes])|| !opcoes.Contains(respostas[alunos,questoes]))
                    {
                        MessageBox.Show("Insira uma resposta válida");
                        questoes--;
                    }
                    else
                    {
                        if (respostas[alunos, questoes] == gabarito[questoes])
                        {
                            compara = "";
                            compara += $"Aluno {alunos + 1} acertou a questão {questoes + 1}, sua resposta foi: {respostas[alunos, questoes]}, e a correta era: {gabarito[questoes]}";
                            lstbxGabarito.Items.Add(compara);
                        }
                        else {
                            compara = "";
                            compara += $"Aluno {alunos + 1} errou a questão {questoes + 1}, sua resposta foi: {respostas[alunos, questoes]} e a correta era: {gabarito[questoes]}";
                            lstbxGabarito.Items.Add(compara);
                        }
                    }
                }
            }
            
        }
    }
}
