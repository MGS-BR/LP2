﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {   
            string[] nomes = new string[10];
            int[] caracter = new int[10];
            for (int i = 0; i < nomes.Length; i++)
            {
                nomes[i] = Interaction.InputBox("Nomes", "Escreva o Nome Completo: ");
                caracter[i] = nomes[i].Replace(" ", "").Length;
            }
            for (int i = 0;i < nomes.Length;i++)
            {
                lstbxNomes.Items.Add("o Nome "+ nomes[i]+ " possui " + caracter[i]+ " caracteres");
            }
        }
        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }
    }
}
