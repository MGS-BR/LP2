﻿namespace PMetodos
{
    partial class FrnExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNumero = new System.Windows.Forms.Button();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchTxtFrase
            // 
            this.rchTxtFrase.Location = new System.Drawing.Point(67, 76);
            this.rchTxtFrase.Name = "rchTxtFrase";
            this.rchTxtFrase.Size = new System.Drawing.Size(346, 132);
            this.rchTxtFrase.TabIndex = 0;
            this.rchTxtFrase.Text = "";
            // 
            // btnContaNumero
            // 
            this.btnContaNumero.Location = new System.Drawing.Point(67, 239);
            this.btnContaNumero.Name = "btnContaNumero";
            this.btnContaNumero.Size = new System.Drawing.Size(126, 67);
            this.btnContaNumero.TabIndex = 1;
            this.btnContaNumero.Text = "Contar Números";
            this.btnContaNumero.UseVisualStyleBackColor = true;
            this.btnContaNumero.Click += new System.EventHandler(this.btnContaNumero_Click);
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Location = new System.Drawing.Point(199, 239);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(128, 67);
            this.btnCaracterBranco.TabIndex = 2;
            this.btnCaracterBranco.Text = "1º Vazio";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Location = new System.Drawing.Point(333, 239);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(126, 67);
            this.btnContaLetra.TabIndex = 3;
            this.btnContaLetra.Text = "Contar Letra";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.btnContaLetra_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(63, 38);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(81, 20);
            this.lbl1.TabIndex = 4;
            this.lbl1.Text = "Seu texto:";
            // 
            // FrnExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnContaNumero);
            this.Controls.Add(this.rchTxtFrase);
            this.Name = "FrnExercicio4";
            this.Text = "FrnExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtFrase;
        private System.Windows.Forms.Button btnContaNumero;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnContaLetra;
        private System.Windows.Forms.Label lbl1;
    }
}