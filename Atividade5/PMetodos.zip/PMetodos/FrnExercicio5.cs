﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FrnExercicio5 : Form
    {
        public FrnExercicio5()
        {
            InitializeComponent();
        }

        private void FrnExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            bool verifica1 = int.TryParse(txtNumero1.Text, out int numero1);
            bool verifica2 = int.TryParse(txtNumero2.Text, out int numero2);

            if (!verifica1 || !verifica2)
            {
                MessageBox.Show("Digite apenas números válidos");
                return;
            }
            if (numero2 <= numero1)
            {
                MessageBox.Show("O segundo Número deve ser maior que o primeiro");
                return;
            }

            Random rnd = new Random();

            int sorteado = rnd.Next(numero1, numero2 + 1);


            MessageBox.Show("Número sorteado: " + sorteado);
        }
    }
}
