﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FrnExercicio4 : Form
    {
        public FrnExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;
            while (posicao < rchTxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchTxtFrase.Text[posicao]))
                {
                    contaNum++;
                }
                posicao++;
            }
            MessageBox.Show($"O texto tem {contaNum} números");
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            for (var i=0; i < rchTxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchTxtFrase.Text[i]))
                {
                    MessageBox.Show($"Posição {i+1}");
                    break;
                }
            }
        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (var c in rchTxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letras");
        }
    }
}
