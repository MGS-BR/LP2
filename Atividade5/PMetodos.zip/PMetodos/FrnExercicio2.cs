﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FrnExercicio2 : Form
    {
        public FrnExercicio2()
        {
            InitializeComponent();
        }

        private void FrnExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            if (palavra1 == palavra2)
            {
                MessageBox.Show("Iguais");
            }
            else
            {
                MessageBox.Show("Diferentes");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            int meio = palavra2.Length/2;

            string resultado = palavra2.Insert(meio, palavra1);

            txtPalavra2.Text = resultado;
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;

            int meio = palavra1.Length/2;

            string resultado = palavra1.Insert(meio, "**");

            txtPalavra2.Text = resultado;
        }
    }
}
