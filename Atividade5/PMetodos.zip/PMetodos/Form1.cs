﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("menu copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("menu colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrnExercicio2>().Count() >0)
            {
                Application.OpenForms["FrnExercicio2"].BringToFront();
            }
            else
            {
                FrnExercicio2 objFrn2 = new FrnExercicio2();
                objFrn2.MdiParent = this;
                objFrn2.WindowState = FormWindowState.Maximized;
                objFrn2.Show();
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrnExercicio3>().Count() > 0)
            {
                Application.OpenForms["FrnExercicio3"].BringToFront();
            }
            else
            {
                FrnExercicio3 objFrn3 = new FrnExercicio3();
                objFrn3.MdiParent = this;
                objFrn3.WindowState = FormWindowState.Maximized;
                objFrn3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrnExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrnExercicio4"].BringToFront();
            }
            else
            {
                FrnExercicio4 objFrn4 = new FrnExercicio4();
                objFrn4.MdiParent = this;
                objFrn4.WindowState = FormWindowState.Maximized;
                objFrn4.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrnExercicio5>().Count() > 0)
            {
                Application.OpenForms["FrnExercicio5"].BringToFront();
            }
            else
            {
                FrnExercicio5 objFrn5 = new FrnExercicio5();
                objFrn5.MdiParent = this;
                objFrn5.WindowState = FormWindowState.Maximized;
                objFrn5.Show();
            }
        }
    }
}
