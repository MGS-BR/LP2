﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        public double numero1, numero2;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "Número 1 Inválido");
                txtNumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNumero1, "");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Convert.ToString(numero1 + numero2);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Convert.ToString(numero1 - numero2);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Convert.ToString(numero1 * numero2);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(numero2 == 0)
            {
                errorProvider3.SetError(txtResultado, "Digite um Número diferente de 0");
                txtNumero2.Focus();

            }
            else
            {
                errorProvider3.SetError(txtResultado, "");
                txtResultado.Text = Convert.ToString(numero1 / numero2);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "Número 2 Inválido");
                txtNumero2.Focus();
            }
        }
    }
}
