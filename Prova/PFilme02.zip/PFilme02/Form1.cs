﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double nota;
            string avaliacao;
            double[,] respostas = new double[2, 2];
            
            for (int pessoa = 0; pessoa < 2; pessoa++)
            {
                for (int filme = 0; filme < 2; filme++)
                {
                    avaliacao = Interaction.InputBox("AVALIACAO", "Digite a sua avaliação de 0-10: ");
                    if (!double.TryParse(avaliacao, out respostas[pessoa, filme]))
                    {
                        MessageBox.Show("Resposta Inválida!");
                        filme--;
                    }
                    else
                    {
                        nota = Convert.ToDouble(avaliacao);
                        MessageBox.Show(""+nota);
                        if (nota > 10 || nota < 0)
                        {
                            MessageBox.Show("Resposta Inválida!");
                            filme--;
                        }
                    }
                }
                avaliacao = $"Pessoa: {pessoa + 1} | Nota Filme 1: {respostas[pessoa, 0].ToString("N2")} | Nota Filme 2: {respostas[pessoa, 1].ToString("N2")}";
                listbxNotas.Items.Add(avaliacao);
            }
            double media1 = (respostas[0, 0] + respostas[1, 0]) / 2;
            double media2 = (respostas[0, 1] + respostas[1, 1]) / 2;
            listbxNotas.Items.Add("---------------------------------");
            listbxNotas.Items.Add($"Média Filme 1: {media1.ToString("N2")}");
            listbxNotas.Items.Add($"Média Filme 2: {media2.ToString("N2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listbxNotas.Items.Clear();
        }
    }
}
