﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public double peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso1.Text, out peso))
            {
                errorProvider1.SetError(txtPeso1, "Digite um peso válido!");
                txtPeso1.Focus();
            }
            else if (peso <= 0)
            {
                errorProvider1.SetError(txtPeso1, "Digite um peso maior que zero!");
                txtPeso1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtPeso1, "");
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                errorProvider2.SetError(txtAltura, "Digite uma altura válida!");
                txtAltura.Focus();
            }
            else if (altura <= 0 || altura > 3)
            {
                errorProvider2.SetError(txtAltura, "Digite uma altura válida!");
                txtAltura.Focus();
            }
            else
            {
                errorProvider2.SetError(txtAltura, "");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(Convert.ToString(txtPeso.Text));

            double IMC = peso / (altura * altura);
            IMC = Math.Round(IMC, 1);

            if(IMC < 18.5)
            {
                txtImc.Text = (Convert.ToString(IMC) + " - Magreza");
            }
            else if (IMC < 24.9)
            {
                txtImc.Text = (Convert.ToString(IMC) + " - Normal");
            }
            else if (IMC < 29.9)
            {
                txtImc.Text = (IMC.ToString() + " - Sobrepeso");
            }
            else if (IMC < 39.9)
            {
                txtImc.Text = (Convert.ToString(IMC) + " - Obsesidade");
            }
            else
            {
                txtImc.Text = (Convert.ToString(IMC) + " - Obsesidade Grave");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso1.Text = "";
            txtImc.Text = "";
        }
    }
}
